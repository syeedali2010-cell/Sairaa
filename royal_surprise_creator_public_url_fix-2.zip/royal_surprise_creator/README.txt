ROYAL SURPRISE STUDIO

IMPORTANT: Do not open index.html directly from your phone's Downloads or file manager. That creates a private content:// address, which cannot be used in a QR code for another phone.

1. Extract this ZIP.
2. Publish the included index.html on a static website host such as Netlify or GitHub Pages.
3. Open the public HTTPS website address (it must begin with https://).
4. Fill in the gift editor and tap “Create this gift”.
5. Scan the QR with another phone's camera. It should open the gift page.

The app now detects local content:// and file:// addresses and explains that publishing is required instead of creating a broken QR.

Photos and music selected from a device are local files and are not uploaded, so they will not appear on another phone unless separately hosted online and added to the website. Keep the published website online at the same address for the QR to keep working.
